
package BookStore;

//IMPORTS
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

/* **********************************************************
 * Programmer:      Erika Tvaskis
 * Class:           CS30S
 * Assignment 5:    GUI Controller 
 * Description:     Conroller class for book store helper app
 *                  controls the model and the view
 * *************************************************************
 */

public class Controller
 {  //Begin class
 	
//DECLARATION OF VARIABLES

        public ArrayList<Book> BookList = new ArrayList();
        private Book p;
        private BookGUI ui;			
        private String[] tokens;                  
         
//CONSTRUCTORS
     
//*****************************************************
// Purpose: Create a new controllor object
// Interface: IN: None
// Returns: None
// *****************************************************	 
    public Controller(){
        System.out.println("controll created.");
    } //end Controller constructor
 	
//ACCESSORS
         
//*****************************************************
// Purpose: Get information on a book and return it to controller
// Interface: IN: i: Index of requested patient record
// Returns: Formatted string of patient info
// *****************************************************
    protected String getBook(int i){
        String st = "";
        p = (Book) ui.BookListModel.getElementAt(i);
        st = "Order ID: " + p.getId() + "\n";

        tokens = p.toString().split(":");

        String BookName = tokens[1];
        String AuthorsName = tokens[2];
        st+= "Book Name: " + BookName + "\n";
        st+= "Author: " + AuthorsName + "\n";

        int Pages = Integer.parseInt(tokens[3]);
        String BookType = tokens[4];
        String FictionType = tokens[5];
        String NonFictionType = tokens[6];
        String ReferencePublicationType = tokens[7];
        String SpecificBookType = null;
        String StyleBookType = tokens[8];

        //IF AND SWITCH STATEMENTS SO MORE INFORMATION CAN BE DISPLAYED
        if (BookType.equals("F")) {
            BookType = "Fiction";
            switch (FictionType) {
                case "M":
                    SpecificBookType = "Mystery";     
                break;
                case "S":
                    SpecificBookType = "Science";
                break;
                case "F":
                    SpecificBookType = "Fantasy";
                break;
                case "H":
                    SpecificBookType = "Horror"; 
                break;
                case "R":
                    SpecificBookType = "Romance";
                break;
                default:
                    SpecificBookType = "Not Selected";
            } //End switch FictionType
        } //End if BookType equals "F"

        else if (BookType.equals("N")) {
            BookType = "Non-Fiction";
            switch (NonFictionType) {
                case "A":
                    SpecificBookType = "AutoBiography";     
                break;
                case "B":
                    SpecificBookType = "Biography";
                break;
                default:
                    SpecificBookType = "Not Selected";
            } //End switch NonFictionType
        } //End if BookType equals "N"

        else if (BookType.equals("R")) {
            BookType = "Reference Publication";
            switch (ReferencePublicationType) {
                case "C":
                    SpecificBookType = "Cooking Handbook";     
                break;
                case "P":
                    SpecificBookType = "Programming Textbook";
                break;
                case "F":
                    SpecificBookType = "French Bescherelle";
                break;
                case "S":
                    SpecificBookType = "SAT Prep Book";
                break;
                case "M":
                    SpecificBookType = "MLA 2018 Guide";
                break;
                default:
                    SpecificBookType = "Not Selected";
            } //End switch Reference Publication
        } //End if BookType equals "R"

        else {
            BookType = "Not Selected";
            SpecificBookType = "Not Available";
        } //End else

        switch(StyleBookType) {
            case "A":
                StyleBookType = "Audio Book";
            break;
            case "I":
                StyleBookType = "Ibook";
            break;
            case "P":
                StyleBookType = "PaperBack";
            break;
            case "H":
                StyleBookType = "Hardcover";
            break;
            default:
                StyleBookType = "Not Selected";
        } //End switch StyleBookType

        st += "Pages: "  + Pages + "\n";
        st+= "Genre: " + BookType + "\n";
        st += "Specific Type: " + SpecificBookType + "\n";
        st += "Style Type: " + StyleBookType + "\n";

        if (p.getTotalBookCost()< 0) {
            st+= "Cost of the Book: Not Available" + "\n";
        } //End if TotalBookCost is less than zero
        else {
        st += "Cost of the Book: " + p.getTotalBookCost() + "\n";
        } //End else

        return st;
    } // end getBook
 	
//MUTATORS
 	
//*****************************************************
// Purpose: Create a new book order and add it to the list
// Interface: IN: book details
// Returns: none
// *****************************************************
    protected void submitButtonClickedInView(String bn, String an, int d,
        char bt, char ft, char nft, char rpt, char style, boolean r, int oldid){
            r = false;
            p = new Book(bn, an, d, bt, ft, nft, rpt, style,r, oldid);
            BookList.add(p);
            ui.BookListModel.addElement(p);
    } // End submitButtonClickedInView
         
//*****************************************************
// Purpose: Replace a book order and add it to the list
// Interface: IN: book details
// Returns: none
// *****************************************************        
    protected void replaceButtonClickedInView(String bn, String an, int d,
        char bt, char ft, char nft, char rpt, char style, int n, boolean r, int oldid){
            r = true;
            tokens = p.toString().split(":");
            oldid = Integer.parseInt(tokens[0]);
            System.out.print(ui.BookListModel.get(n) + " " + oldid + "\n");
            p = new Book(bn, an, d, bt, ft, nft, rpt, style,r, oldid);
            ui.BookListModel.setElementAt(p, n);
    } // End replaceButtonClickedInView
          
//*****************************************************
// Purpose: Register the view with the controller
// Interface: IN: view object
// Returns: 
// *****************************************************
    protected void addUI(BookGUI g){
        this.ui = g;
    } //End addUI
	 
//*****************************************************
// Purpose: Write the book list to a random access disk file
// Interface: IN: none, patient list is property of this class
// Returns: none
// ***************************************************** 
    protected void writeBookList(){
        try{
            FileOutputStream fos = new FileOutputStream("book.tmp");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(BookList);
            oos.close();
        } //End try
        catch(IOException e){
        } //End catch IOException
    } //End writeBookList
	 
//*****************************************************
// Purpose: Get the book list from disk file, called from gui
// Interface: IN: none
// Returns: none
// *****************************************************
    protected void getBookList(){
        try{
            FileInputStream fis = new FileInputStream("book.tmp");
            ObjectInputStream ois = new ObjectInputStream(fis);
            try{
                BookList = (ArrayList<Book>)ois.readObject();
            } //End try loading array list
            catch(ClassNotFoundException e){
            } //End catch class not found			 
        } //End try
        catch(IOException e){	 
        } //End catch IOException on input file stream
	
        ui.loadBookListModel(BookList);
    } //End getBookList
         
//*****************************************************
// Purpose: Set the next ID property to n when list is loaded from disk
// Interface: IN: Book: p
// Returns: none
// ***************************************************** 
    protected void loadListButtonClicked(Book p){
        int nid = p.getId();
        p.setNextId(++nid);
    } //End loadListButtonClicked   
	 
 }  //End class