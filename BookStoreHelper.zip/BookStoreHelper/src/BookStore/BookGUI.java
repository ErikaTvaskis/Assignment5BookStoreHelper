
package BookStore;

//IMPORTS
import java.util.ArrayList;
import javax.swing.DefaultListModel;

/* **********************************************************
 * Programmer:      Erika Tvaskis
 * Class:           CS30S
 * Assignment 5:    GUI View
 * Description:     View and its methods
 * *************************************************************
 */

public class BookGUI extends javax.swing.JFrame 
 { //Begin class
	
//DELCARATION OF INSTANCE VARAIBLES AND OBJECTS
	
    protected Controller c; //Controller object
    protected DefaultListModel BookListModel = new DefaultListModel();
    protected DefaultListModel patientListModel = BookListModel;
    protected int Index = 0;
    private String[] tokens;   

//CREATES NEW FORM BookGUI
    public BookGUI() {
        initComponents();
    } //Closing bracket BookGUI

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        inputPanel = new javax.swing.JPanel();
        BookNameLabel = new javax.swing.JLabel();
        BookNameText = new javax.swing.JTextField();
        Length = new javax.swing.JSpinner();
        BookTypeCombo = new javax.swing.JComboBox<>();
        StyleTypeCombo = new javax.swing.JComboBox<>();
        NonFictionTypeCombo = new javax.swing.JComboBox<>();
        ReferencePublicationTypeCombo = new javax.swing.JComboBox<>();
        ClearButton = new javax.swing.JButton();
        AuthorsNameText = new javax.swing.JTextField();
        AuthorsNameLabel = new javax.swing.JLabel();
        LengthLabel = new javax.swing.JLabel();
        BookTypeLabel = new javax.swing.JLabel();
        FictionTypeLabel = new javax.swing.JLabel();
        NonFictionLabel = new javax.swing.JLabel();
        ReferencePublicationTypeLabel = new javax.swing.JLabel();
        StyleTypeLabel = new javax.swing.JLabel();
        FictionTypeCombo = new javax.swing.JComboBox<>();
        EnterYourDesiredBookLabel1 = new javax.swing.JLabel();
        SubmitButton = new javax.swing.JButton();
        ReplaceButton = new javax.swing.JButton();
        infoPanel = new javax.swing.JPanel();
        loadBtn = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        try {
            BookInfoText =(javax.swing.JTextArea)java.beans.Beans.instantiate(getClass().getClassLoader(), "BookStore.BookGUI_BookInfoText");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (java.io.IOException e) {
            e.printStackTrace();
        }
        BookListScrollPane = new javax.swing.JScrollPane();
        BookList = new javax.swing.JList<>();
        EnterYourDesiredBookLabel = new javax.swing.JLabel();
        BookNameLabel1 = new javax.swing.JLabel();
        BookNameLabel2 = new javax.swing.JLabel();
        GIFButton = new javax.swing.JButton();
        BookNameLabel3 = new javax.swing.JLabel();
        DeleteButton = new javax.swing.JButton();
        saveBtn = new javax.swing.JButton();
        jTextFieldHelpDelete = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Patient Information");
        setBackground(new java.awt.Color(0, 255, 102));

        inputPanel.setBackground(new java.awt.Color(142, 217, 255));
        inputPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        inputPanel.setName("inputPanel"); // NOI18N

        BookNameLabel.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        BookNameLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        BookNameLabel.setText("Book Name:");
        BookNameLabel.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BookNameLabel.setMaximumSize(new java.awt.Dimension(75, 15));
        BookNameLabel.setMinimumSize(new java.awt.Dimension(75, 15));
        BookNameLabel.setPreferredSize(new java.awt.Dimension(75, 15));

        BookNameText.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        BookNameText.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        BookNameText.setPreferredSize(new java.awt.Dimension(70, 20));

        Length.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        BookTypeCombo.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        BookTypeCombo.setMaximumRowCount(4);
        BookTypeCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select One", "Fiction", "Non-Fiction", "Reference Publication" }));
        BookTypeCombo.setBorder(null);
        BookTypeCombo.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                BookTypeComboItemStateChanged(evt);
            }
        });

        StyleTypeCombo.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        StyleTypeCombo.setMaximumRowCount(4);
        StyleTypeCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select One", "Audio Book", "Ibook", "Paperback", "Hardcover" }));
        StyleTypeCombo.setBorder(null);

        NonFictionTypeCombo.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        NonFictionTypeCombo.setMaximumRowCount(3);
        NonFictionTypeCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select One", "AutoBiography", "Biography" }));
        NonFictionTypeCombo.setBorder(null);

        ReferencePublicationTypeCombo.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        ReferencePublicationTypeCombo.setMaximumRowCount(6);
        ReferencePublicationTypeCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select One", "Cooking Handbook", "Programming Textbook", "French Bescherelle", "SAT Prep Book", "MLA 2018 Guide" }));
        ReferencePublicationTypeCombo.setBorder(null);

        ClearButton.setBackground(new java.awt.Color(255, 255, 255));
        ClearButton.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        ClearButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BookStore/LargeButton.jpg"))); // NOI18N
        ClearButton.setText("Clear");
        ClearButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        ClearButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        ClearButton.setMargin(new java.awt.Insets(57, 17, 17, 17));
        ClearButton.setPreferredSize(new java.awt.Dimension(57, 23));
        ClearButton.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/BookStore/LargeClicked.jpg"))); // NOI18N
        ClearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearButtonActionPerformed(evt);
            }
        });

        AuthorsNameText.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        AuthorsNameText.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        AuthorsNameText.setMinimumSize(new java.awt.Dimension(75, 20));
        AuthorsNameText.setPreferredSize(new java.awt.Dimension(75, 20));

        AuthorsNameLabel.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        AuthorsNameLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        AuthorsNameLabel.setText("Author's Name:");
        AuthorsNameLabel.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        AuthorsNameLabel.setMaximumSize(new java.awt.Dimension(75, 15));
        AuthorsNameLabel.setMinimumSize(new java.awt.Dimension(75, 15));
        AuthorsNameLabel.setPreferredSize(new java.awt.Dimension(75, 15));

        LengthLabel.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        LengthLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LengthLabel.setText("Length:");

        BookTypeLabel.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        BookTypeLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        BookTypeLabel.setText("Book Type:");

        FictionTypeLabel.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        FictionTypeLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        FictionTypeLabel.setText("Fiction Type:");

        NonFictionLabel.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        NonFictionLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        NonFictionLabel.setText("Non-Fiction Type:");

        ReferencePublicationTypeLabel.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        ReferencePublicationTypeLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ReferencePublicationTypeLabel.setText("Ref. Publication Type:");

        StyleTypeLabel.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        StyleTypeLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        StyleTypeLabel.setText("Style Type:");

        FictionTypeCombo.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        FictionTypeCombo.setMaximumRowCount(6);
        FictionTypeCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select One", "Mystery", "Science", "Fantasy", "Horror", "Romance" }));
        FictionTypeCombo.setBorder(null);
        FictionTypeCombo.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        EnterYourDesiredBookLabel1.setBackground(new java.awt.Color(255, 255, 255));
        EnterYourDesiredBookLabel1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        EnterYourDesiredBookLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        EnterYourDesiredBookLabel1.setText("Enter Your Desired Book");
        EnterYourDesiredBookLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        EnterYourDesiredBookLabel1.setOpaque(true);

        SubmitButton.setBackground(new java.awt.Color(255, 255, 255));
        SubmitButton.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        SubmitButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BookStore/LargeButton.jpg"))); // NOI18N
        SubmitButton.setText("Submit");
        SubmitButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        SubmitButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        SubmitButton.setMaximumSize(new java.awt.Dimension(57, 23));
        SubmitButton.setMinimumSize(new java.awt.Dimension(57, 23));
        SubmitButton.setPreferredSize(new java.awt.Dimension(57, 23));
        SubmitButton.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/BookStore/LargeClicked.jpg"))); // NOI18N
        SubmitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SubmitButtonActionPerformed(evt);
            }
        });

        ReplaceButton.setBackground(new java.awt.Color(255, 255, 255));
        ReplaceButton.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        ReplaceButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BookStore/LargeButton.jpg"))); // NOI18N
        ReplaceButton.setText("Replace");
        ReplaceButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        ReplaceButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        ReplaceButton.setPreferredSize(new java.awt.Dimension(57, 23));
        ReplaceButton.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/BookStore/LargeClicked.jpg"))); // NOI18N
        ReplaceButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReplaceButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout inputPanelLayout = new javax.swing.GroupLayout(inputPanel);
        inputPanel.setLayout(inputPanelLayout);
        inputPanelLayout.setHorizontalGroup(
            inputPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inputPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(inputPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(EnterYourDesiredBookLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(inputPanelLayout.createSequentialGroup()
                        .addGroup(inputPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(BookNameLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 98, Short.MAX_VALUE)
                            .addComponent(BookNameText, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(SubmitButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(inputPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(inputPanelLayout.createSequentialGroup()
                                .addGroup(inputPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(inputPanelLayout.createSequentialGroup()
                                        .addComponent(AuthorsNameLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(7, 7, 7))
                                    .addGroup(inputPanelLayout.createSequentialGroup()
                                        .addComponent(AuthorsNameText, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                .addGroup(inputPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(LengthLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 56, Short.MAX_VALUE)
                                    .addComponent(Length))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(inputPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(BookTypeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE)
                                    .addComponent(BookTypeCombo, 0, 1, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(inputPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(FictionTypeCombo, 0, 90, Short.MAX_VALUE)
                                    .addComponent(FictionTypeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(18, 18, 18)
                                .addGroup(inputPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(NonFictionTypeCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(NonFictionLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(inputPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(ReferencePublicationTypeCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(ReferencePublicationTypeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(18, 18, 18)
                                .addGroup(inputPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(StyleTypeCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(StyleTypeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(inputPanelLayout.createSequentialGroup()
                                .addComponent(ClearButton, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(ReplaceButton, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addGap(18, 18, 18))
        );
        inputPanelLayout.setVerticalGroup(
            inputPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inputPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(EnterYourDesiredBookLabel1)
                .addGap(10, 10, 10)
                .addGroup(inputPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BookNameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(AuthorsNameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LengthLabel)
                    .addComponent(BookTypeLabel)
                    .addComponent(FictionTypeLabel)
                    .addComponent(StyleTypeLabel)
                    .addComponent(ReferencePublicationTypeLabel)
                    .addComponent(NonFictionLabel))
                .addGap(3, 3, 3)
                .addGroup(inputPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BookNameText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Length, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(AuthorsNameText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BookTypeCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(FictionTypeCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(StyleTypeCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ReferencePublicationTypeCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(NonFictionTypeCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(inputPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SubmitButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ClearButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ReplaceButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        infoPanel.setBackground(new java.awt.Color(51, 153, 255));
        infoPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        infoPanel.setName("infoPanel"); // NOI18N

        loadBtn.setBackground(new java.awt.Color(251, 132, 125));
        loadBtn.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        loadBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BookStore/Pink (4).jpg"))); // NOI18N
        loadBtn.setText("Load");
        loadBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        loadBtn.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        loadBtn.setMaximumSize(new java.awt.Dimension(57, 23));
        loadBtn.setMinimumSize(new java.awt.Dimension(57, 23));
        loadBtn.setPreferredSize(new java.awt.Dimension(57, 23));
        loadBtn.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/BookStore/PinkPressed (2).jpg"))); // NOI18N
        loadBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loadBtnActionPerformed(evt);
            }
        });

        jScrollPane2.setViewportView(BookInfoText);

        BookList.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        BookList.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        BookList.setModel(patientListModel);
        BookList.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                BookListValueChanged(evt);
            }
        });
        BookListScrollPane.setViewportView(BookList);

        EnterYourDesiredBookLabel.setBackground(new java.awt.Color(255, 255, 255));
        EnterYourDesiredBookLabel.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        EnterYourDesiredBookLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        EnterYourDesiredBookLabel.setText("Information On Your Desired Book");
        EnterYourDesiredBookLabel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        EnterYourDesiredBookLabel.setMaximumSize(new java.awt.Dimension(158, 19));
        EnterYourDesiredBookLabel.setMinimumSize(new java.awt.Dimension(158, 19));
        EnterYourDesiredBookLabel.setOpaque(true);
        EnterYourDesiredBookLabel.setPreferredSize(new java.awt.Dimension(158, 19));

        BookNameLabel1.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        BookNameLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        BookNameLabel1.setText("Books:");
        BookNameLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BookNameLabel1.setMaximumSize(new java.awt.Dimension(75, 15));
        BookNameLabel1.setMinimumSize(new java.awt.Dimension(75, 15));
        BookNameLabel1.setPreferredSize(new java.awt.Dimension(75, 15));

        BookNameLabel2.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        BookNameLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        BookNameLabel2.setText("Book Information:");
        BookNameLabel2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BookNameLabel2.setMaximumSize(new java.awt.Dimension(75, 15));
        BookNameLabel2.setMinimumSize(new java.awt.Dimension(75, 15));
        BookNameLabel2.setPreferredSize(new java.awt.Dimension(75, 15));

        GIFButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BookStore/Booklet (2).gif"))); // NOI18N
        GIFButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        GIFButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        GIFButton.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/BookStore/Untitled.png"))); // NOI18N

        BookNameLabel3.setBackground(new java.awt.Color(105, 118, 159));
        BookNameLabel3.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        BookNameLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        BookNameLabel3.setText("Press Me!");
        BookNameLabel3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BookNameLabel3.setMaximumSize(new java.awt.Dimension(75, 15));
        BookNameLabel3.setMinimumSize(new java.awt.Dimension(75, 15));
        BookNameLabel3.setPreferredSize(new java.awt.Dimension(75, 15));

        DeleteButton.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        DeleteButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BookStore/LargeButton.jpg"))); // NOI18N
        DeleteButton.setText("Delete");
        DeleteButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        DeleteButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        DeleteButton.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/BookStore/LargeClicked.jpg"))); // NOI18N
        DeleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteButtonActionPerformed(evt);
            }
        });

        saveBtn.setBackground(new java.awt.Color(251, 132, 125));
        saveBtn.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        saveBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BookStore/Pink (4).jpg"))); // NOI18N
        saveBtn.setText("Save");
        saveBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        saveBtn.setContentAreaFilled(false);
        saveBtn.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        saveBtn.setOpaque(true);
        saveBtn.setPreferredSize(new java.awt.Dimension(57, 23));
        saveBtn.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/BookStore/PinkPressed (2).jpg"))); // NOI18N
        saveBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveBtnActionPerformed(evt);
            }
        });

        jTextFieldHelpDelete.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jTextFieldHelpDelete.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldHelpDelete.setToolTipText("");
        jTextFieldHelpDelete.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jLabel1.setText("Enter ID to Delete:");

        javax.swing.GroupLayout infoPanelLayout = new javax.swing.GroupLayout(infoPanel);
        infoPanel.setLayout(infoPanelLayout);
        infoPanelLayout.setHorizontalGroup(
            infoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(infoPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(infoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(EnterYourDesiredBookLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(infoPanelLayout.createSequentialGroup()
                        .addGroup(infoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(BookListScrollPane, javax.swing.GroupLayout.DEFAULT_SIZE, 269, Short.MAX_VALUE)
                            .addComponent(BookNameLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(infoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(infoPanelLayout.createSequentialGroup()
                                .addGap(17, 17, 17)
                                .addGroup(infoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(loadBtn, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(saveBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING)))
                            .addGroup(infoPanelLayout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(infoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jTextFieldHelpDelete)
                                    .addComponent(DeleteButton, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(18, 18, 18)
                        .addGroup(infoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(BookNameLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 317, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(infoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(BookNameLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(GIFButton, javax.swing.GroupLayout.DEFAULT_SIZE, 173, Short.MAX_VALUE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        infoPanelLayout.setVerticalGroup(
            infoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, infoPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(EnterYourDesiredBookLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(infoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BookNameLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BookNameLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BookNameLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(infoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(BookListScrollPane, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(infoPanelLayout.createSequentialGroup()
                        .addGroup(infoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(GIFButton, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(0, 1, Short.MAX_VALUE))
                    .addGroup(infoPanelLayout.createSequentialGroup()
                        .addComponent(jTextFieldHelpDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(DeleteButton, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(saveBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(loadBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );

        EnterYourDesiredBookLabel.getAccessibleContext().setAccessibleName("EnterDesiredBookLabel");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(infoPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(inputPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(inputPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(infoPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BookListValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_BookListValueChanged
        getSetInputs();
    }//GEN-LAST:event_BookListValueChanged

    private void saveBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveBtnActionPerformed
        c.writeBookList();
    }//GEN-LAST:event_saveBtnActionPerformed

    private void loadBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadBtnActionPerformed
        c.getBookList();
    }//GEN-LAST:event_loadBtnActionPerformed

    private void ClearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearButtonActionPerformed
        reSetInputs();
    }//GEN-LAST:event_ClearButtonActionPerformed

    private void SubmitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SubmitButtonActionPerformed
        String BookName = BookNameText.getText();
        String AuthorsName = AuthorsNameText.getText();
        int Length = getAmountofPages();
        char BookType = getBookType();
        char FictionType = getFictionType();
        char NonFictionType = getNonFictionType();
        char ReferencePublicationType = getReferencePublicationType();
        char StyleType = getStyleType();
        boolean r = false;
        int oldid = 0;

        c.submitButtonClickedInView(BookName, AuthorsName, Length, BookType,
            FictionType, NonFictionType, ReferencePublicationType, StyleType, r, oldid);

        reSetInputs();
    }//GEN-LAST:event_SubmitButtonActionPerformed

    private void BookTypeComboItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_BookTypeComboItemStateChanged
        if(BookTypeCombo.getSelectedItem().toString().equals("Fiction")){
            ReferencePublicationTypeCombo.setEnabled(false);
            NonFictionTypeCombo.setEnabled(false);
            StyleTypeCombo.setEnabled(true);
            FictionTypeCombo.setEnabled(true);
            ReferencePublicationTypeCombo.setSelectedIndex(0);
            NonFictionTypeCombo.setSelectedIndex(0);
        } //End if Fiction selected
        else if(BookTypeCombo.getSelectedItem().toString().equals("Non-Fiction")){
            ReferencePublicationTypeCombo.setEnabled(false);
            NonFictionTypeCombo.setEnabled(true);
            StyleTypeCombo.setEnabled(true);
            FictionTypeCombo.setEnabled(false);
            ReferencePublicationTypeCombo.setSelectedIndex(0);
            FictionTypeCombo.setSelectedIndex(0);
        } //End if NonFiction selected
        else if (BookTypeCombo.getSelectedItem().toString().equals("Reference Publication")){
            ReferencePublicationTypeCombo.setEnabled(true);
            NonFictionTypeCombo.setEnabled(false);
            StyleTypeCombo.setEnabled(true);
            FictionTypeCombo.setEnabled(false);
            NonFictionTypeCombo.setSelectedIndex(0);
            FictionTypeCombo.setSelectedIndex(0);
        } //End if Reference Publication selected
        else {
        //System.out.println("book type was not selected");
        } //End else
    }//GEN-LAST:event_BookTypeComboItemStateChanged

    private void ReplaceButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReplaceButtonActionPerformed
        String BookName = BookNameText.getText();
        String AuthorsName = AuthorsNameText.getText();
        int Length = getAmountofPages();
        int n = BookList.getSelectedIndex();
        char BookType = getBookType();
        char FictionType = getFictionType();
        char NonFictionType = getNonFictionType();
        char ReferencePublicationType = getReferencePublicationType();
        char StyleType = getStyleType();
        boolean r = false;
        int oldid = 0;
        
        c.replaceButtonClickedInView(BookName, AuthorsName, Length, BookType,
            FictionType, NonFictionType, ReferencePublicationType, StyleType, n,r ,oldid);

        reSetInputs();    
    }//GEN-LAST:event_ReplaceButtonActionPerformed

    private void DeleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteButtonActionPerformed
        int n = BookList.getSelectedIndex();
        String textFieldValuetoDelete = jTextFieldHelpDelete.getText();
        int found;
        for (int k=0; k<BookListModel.size(); k++) {
            found=0;
            String xxx=BookListModel.get(k).toString();
        
            //IF STATEMENT (if book order to delete empty, found equals 0, else if found equals 1)
            if (textFieldValuetoDelete.equals("")) {
                found = 0;
            } //End if
            else if (xxx.contains(textFieldValuetoDelete)) {
                found=1;
            } //End else 
                
            //IF STATEMENT (if found equals 1 remove element)
            if (found==1 && k!=n) { 
                BookListModel.removeElementAt(k);   
            } //End if found equals 1
        } //End for loop
 
    jTextFieldHelpDelete.setText("");
    reSetInputs();
    }//GEN-LAST:event_DeleteButtonActionPerformed

//*****************************************************
// Purpose: Add books to list model
// Interface: IN: None
// Returns: None
// *****************************************************
    protected void loadBookListModel(ArrayList<Book> list){
        for(Book p: list){
            BookListModel.addElement(p);        
	} //End for loop
	c.loadListButtonClicked(list.get(list.size()-1));
    } //End load BookListModel
        
//*****************************************************
// Purpose: Get the inputs the selected book order has
// Interface: IN: None
// Returns: None
// *****************************************************   
    private void getSetInputs(){
        int n = BookList.getSelectedIndex();
        tokens = c.getBook(n).split(":|\\\n");
        BookNameText.setText(tokens[3]);
        AuthorsNameText.setText(tokens[5]);
        
        //IF STATEMENTS TO GET BOOK TYPE AND SPECIFIC TYPE
        if ((tokens[9]).trim().equals("Fiction")) {
            BookTypeCombo.setSelectedIndex(1);
            if ((tokens[11]).trim().equals("Mystery")) {
                FictionTypeCombo.setSelectedIndex(1);
            } //End if tokens 11 equals Mystery
            else if ((tokens[11]).trim().equals("Science")) {
                FictionTypeCombo.setSelectedIndex(2);
            } //End if tokens 11 equals Science
            else if ((tokens[11]).trim().equals("Fantasy")) {
                FictionTypeCombo.setSelectedIndex(3);
            } //End if tokens 11 equals Fanatasy
            else if ((tokens[11]).trim().equals("Horror")) {
                FictionTypeCombo.setSelectedIndex(4);
            } //End if tokens 11 equals Horror
            else if ((tokens[11]).trim().equals("Romance")) {
                FictionTypeCombo.setSelectedIndex(5);
            } //End if tokens 11 equals Romance
            else {
                FictionTypeCombo.setSelectedIndex(0);
            } //End else
        } //End if tokens 9 equals Fiction
        
        else if ((tokens[9]).trim().equals("Non-Fiction")) {
            BookTypeCombo.setSelectedIndex(2);
            if ((tokens[11]).trim().equals("AutoBiography")) {
                NonFictionTypeCombo.setSelectedIndex(1);
            } //End if tokens 11 equals AutoBiography
            else if ((tokens[11]).trim().equals("Biography")) {
                NonFictionTypeCombo.setSelectedIndex(2);
            } //End if tokens 11 equals Biography
            else {
            NonFictionTypeCombo.setSelectedIndex(0);
            } //End else
        } //End if tokens 9 equals Non-Fiction
        
        else if ((tokens[9]).trim().equals("Reference Publication")) {
            BookTypeCombo.setSelectedIndex(3);
            if ((tokens[11]).trim().equals("Cooking Handbook")) {
                ReferencePublicationTypeCombo.setSelectedIndex(1);
            } //End if tokens 11 equals Cooking Handbook
            else if ((tokens[11]).trim().equals("Programming Textbook")) {
                ReferencePublicationTypeCombo.setSelectedIndex(2);
            } //End if tokens 11 equals Programming Textbook
            else if ((tokens[11]).trim().equals("French Bescherelle")) {
                ReferencePublicationTypeCombo.setSelectedIndex(3);
            } //End if tokens 11 equals French Bescherelle
            else if ((tokens[11]).trim().equals("SAT Prep Book")) {
                ReferencePublicationTypeCombo.setSelectedIndex(4);
            } //End if tokens 11 equals SAT Prep Book
            else if ((tokens[11]).trim().equals("MLA 2018 Guide")) {
                ReferencePublicationTypeCombo.setSelectedIndex(5);
            } //End if tokens 11 equals MLA 2018 Guide
            else {
                ReferencePublicationTypeCombo.setSelectedIndex(0);
            } //End else
        } //End if tokens 9 equals Reference Publication
        
        else {
            BookTypeCombo.setSelectedIndex(0);
        } //End else
            
        //IF STATEMENT TO GET STYLE TYPE      
        if ((tokens[13]).trim().equals("Audio Book")) {
            StyleTypeCombo.setSelectedIndex(1);
        } //End if tokens 13 equals Audio Book
        else if ((tokens[13]).trim().equals("Ibook")) {
            StyleTypeCombo.setSelectedIndex(2);
        } //End if tokens 13 equals IBook
        else if ((tokens[13]).trim().equals("Paperback")) {
            StyleTypeCombo.setSelectedIndex(3);
        } //End if tokens 13 equals Paperback
        else if ((tokens[13]).trim().equals("Hardcover")) {
            StyleTypeCombo.setSelectedIndex(4);
        } //End if tokens 13 equals Hardcover
        else {
            StyleTypeCombo.setSelectedIndex(0);
        } //End else
             
    BookInfoText.setText(c.getBook(n));
    } //End getSetInputs
        
//*****************************************************
// Purpose: Reset inputs
// Interface: IN: None
// Returns: None
// *****************************************************        
    private void reSetInputs(){
        BookNameText.setText("");
        AuthorsNameText.setText("");
        Length.setValue(1);

        BookTypeCombo.setSelectedIndex(0);
        FictionTypeCombo.setSelectedIndex(0);
        StyleTypeCombo.setSelectedIndex(0);
        ReferencePublicationTypeCombo.setSelectedIndex(0);
        NonFictionTypeCombo.setSelectedIndex(0);

        StyleTypeCombo.setEnabled(true);
        ReferencePublicationTypeCombo.setEnabled(true);
        NonFictionTypeCombo.setEnabled(true);
		
	BookNameText.requestFocus();
    } //End reSetInputs
	
//*****************************************************
// Purpose: Get book type
// Interface: IN: None
// Returns: char bt
// *****************************************************   
    private char getBookType(){
        char bt = 'X';		// temp book type code
        if(BookTypeCombo.getSelectedItem().toString().equals("Fiction")){
            bt = 'F';
        } //End if Fiction
        else if(BookTypeCombo.getSelectedItem().toString().equals("Non-Fiction")) {
            bt = 'N';
        } //End if Non-Fiction
        else if (BookTypeCombo.getSelectedItem().toString().equals("Reference Publication")) {
            bt = 'R';	
        } //End if Reference Publication
        else {
            bt = 'X';
        } //End else
        return bt;
    } //End getBookType
    
//*****************************************************
// Purpose: Get fiction type
// Interface: IN: None
// Returns: char ft
// *****************************************************  
    private char getFictionType(){
        char ft = 'X';
        if(FictionTypeCombo.getSelectedItem().toString().equals("Mystery")) {
            ft = 'M'; 
        } //End if FictionTypeCombo equals Mystery
        else if(FictionTypeCombo.getSelectedItem().toString().equals("Science")) {
            ft = 'S';
        } //End if FictionTypeCombo equals Science
        else if(FictionTypeCombo.getSelectedItem().toString().equals("Fantasy")) {
            ft = 'F';
        } //End if FictionTypeCombo equals Fantasy
        else if(FictionTypeCombo.getSelectedItem().toString().equals("Horror")){
            ft = 'H';
        } //End if FictionTypeCombo equals Horror
        else if(FictionTypeCombo.getSelectedItem().toString().equals("Romance")){
            ft = 'R';
        } //End if FictionTypeCombo equals Romance
        else{
            ft = 'X';
        } //End else
        return ft;
    } //End getFictionType

//*****************************************************
// Purpose: Get non-fiction type
// Interface: IN: None
// Returns: char nft
// *****************************************************     
    private char getNonFictionType(){
        char nft = 'X';
        if(NonFictionTypeCombo.getSelectedItem().toString().equals("AutoBiography")) {
            nft = 'A';
        } //End if NonFictionTypeCombo equals AutoBiography
        else if (NonFictionTypeCombo.getSelectedItem().toString().equals("Biography")) {
            nft = 'B';
        } //End if NonFictionTypeCombo equals Biography
        else {
            nft = 'X';
        } //End else
	return nft;
    } //End getNonFictionType
    
//*****************************************************
// Purpose: Get reference publication type
// Interface: IN: None
// Returns: char rpt
// *****************************************************     
    private char getReferencePublicationType(){
        char rpt;
        if(ReferencePublicationTypeCombo.getSelectedItem().toString().equals("Cooking Handbook")) {
            rpt = 'C';
        } //End if ReferencePublicationTypeCombo equals Cooking Handbook
        else if(ReferencePublicationTypeCombo.getSelectedItem().toString().equals("Programming Textbook")) {
            rpt = 'P';
        } //End if ReferencePublicationTypeCombo equals Programming Textbook
        else if(ReferencePublicationTypeCombo.getSelectedItem().toString().equals("French Bescherelle")) {
            rpt = 'F';
        } //End if ReferencePublicationTypeCombo equals French Bescherelle
        else if(ReferencePublicationTypeCombo.getSelectedItem().toString().equals("SAT Prep Book")) {
            rpt = 'S';
        } //End if ReferencePublicationTypeCombo equals SAT Prep Book
        else if(ReferencePublicationTypeCombo.getSelectedItem().toString().equals("MLA 2018 Guide")) { 
            rpt = 'M';
        } //End if ReferencePublicationTypeCombo equals MLA 2018 Guide
        else {
            rpt = 'X';
        } //End else
	return rpt;
    } //End getReferencePublicationType	
        
//*****************************************************
// Purpose: Get style type
// Interface: IN: None
// Returns: char st
// *****************************************************             
    private char getStyleType(){
        char st;
        if (StyleTypeCombo.getSelectedItem().toString().equals("Audio Book")) {
            st = 'A';
        } //End if StyleTypeCombo equals Audio Book
        else  if (StyleTypeCombo.getSelectedItem().toString().equals("Ibook")) {
            st = 'I';
        } //End if StyleTypeCombo equals Ibook
        else  if (StyleTypeCombo.getSelectedItem().toString().equals("Paperback")) {
            st = 'P';
        } //End if StyleTypeCombo equals Paperback
        else  if (StyleTypeCombo.getSelectedItem().toString().equals("Hardcover")) {
            st = 'H';
        } //End if StyleTypeCombo equals Hardcover
        else {
            st = 'X';
        } //End else
            return st;
    } //End getStyleType
	
//*****************************************************
// Purpose: Get amount of pages
// Interface: IN: None
// Returns: return Amount of pages
// *****************************************************          
    private int getAmountofPages(){
        return Integer.parseInt(Length.getValue().toString());
    } //End getAmountofPages
	
//SETTER METHODS
	
//*****************************************************
// Purpose: Add a contoller object to this ui
// Interface: IN: Controller object c
// Returns: none
// ***************************************************** 
    protected void addController(Controller c){
        this.c = c;
    } //End addUI	
	
	
//		//<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
//		/*
//		 * If Nimbus (introduced in Java SE 6) is not available, stay with the
//		 * default look and feel. For details see
//		 * http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
//		 */
//		try {
//			for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//				if ("Nimbus".equals(info.getName())) {
//					javax.swing.UIManager.setLookAndFeel(info.getClassName());
//					break;
//				}
//			}
//		} catch (ClassNotFoundException ex) {
//			java.util.logging.Logger.getLogger(PatientGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//		} catch (InstantiationException ex) {
//			java.util.logging.Logger.getLogger(PatientGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//		} catch (IllegalAccessException ex) {
//			java.util.logging.Logger.getLogger(PatientGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//		} catch (javax.swing.UnsupportedLookAndFeelException ex) {
//			java.util.logging.Logger.getLogger(PatientGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//		}
//		//</editor-fold>

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AuthorsNameLabel;
    private javax.swing.JTextField AuthorsNameText;
    private javax.swing.JTextArea BookInfoText;
    private javax.swing.JList<String> BookList;
    private javax.swing.JScrollPane BookListScrollPane;
    private javax.swing.JLabel BookNameLabel;
    private javax.swing.JLabel BookNameLabel1;
    private javax.swing.JLabel BookNameLabel2;
    private javax.swing.JLabel BookNameLabel3;
    private javax.swing.JTextField BookNameText;
    private javax.swing.JComboBox<String> BookTypeCombo;
    private javax.swing.JLabel BookTypeLabel;
    private javax.swing.JButton ClearButton;
    private javax.swing.JButton DeleteButton;
    private javax.swing.JLabel EnterYourDesiredBookLabel;
    private javax.swing.JLabel EnterYourDesiredBookLabel1;
    private javax.swing.JComboBox<String> FictionTypeCombo;
    private javax.swing.JLabel FictionTypeLabel;
    private javax.swing.JButton GIFButton;
    private javax.swing.JSpinner Length;
    private javax.swing.JLabel LengthLabel;
    private javax.swing.JLabel NonFictionLabel;
    private javax.swing.JComboBox<String> NonFictionTypeCombo;
    private javax.swing.JComboBox<String> ReferencePublicationTypeCombo;
    private javax.swing.JLabel ReferencePublicationTypeLabel;
    private javax.swing.JButton ReplaceButton;
    private javax.swing.JComboBox<String> StyleTypeCombo;
    private javax.swing.JLabel StyleTypeLabel;
    private javax.swing.JButton SubmitButton;
    private javax.swing.JPanel infoPanel;
    private javax.swing.JPanel inputPanel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jTextFieldHelpDelete;
    private javax.swing.JButton loadBtn;
    private javax.swing.JButton saveBtn;
    // End of variables declaration//GEN-END:variables
}
