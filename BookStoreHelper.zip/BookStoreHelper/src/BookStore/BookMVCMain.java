
package BookStore;

/* **********************************************************
 * Programmer:      Erika Tvaskis
 * Class:           CS30S
 * Assignment 5:    GUI Main
 * Description:     Run the project from this class
 * *************************************************************
 */
 
public class BookMVCMain 
 { //Begin class
    
public static void main(String[] args) 
 { //Begin main
    
//PRINT OUTPUT BANNER
     
    System.out.println("*******************************************");
    System.out.println("Name:		Erika Tvaskis");
    System.out.println("Class:		CS30S");
    System.out.println("Assignment 5:	GUI");
    System.out.println("*******************************************");

//PROCESSING

    BookGUI BookUI = new BookGUI();
    BookUI.setVisible(true);

    Controller controller = new Controller();
    controller.addUI(BookUI); //Register view with controller
    BookUI.addController(controller); //Register controller with view
    
//CLOSING MESSAGE  

    System.out.println("End of processing.");
    
} //End main

} //End class
