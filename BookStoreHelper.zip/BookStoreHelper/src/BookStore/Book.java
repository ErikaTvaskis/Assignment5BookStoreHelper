
package BookStore;

//IMPORTS
import java.io.Serializable;
import static jdk.nashorn.internal.objects.NativeString.trim;

/* **********************************************************
 * Programmer:      Erika Tvaskis
 * Class:           CS30S
 * Assignment 5:    GUI model
 * Description:     Calculates book order cost
 * *************************************************************
 */

public class Book implements Serializable
 {  //Begin class
    
//DELCARATION OF CLASS VARIABLES
    private static int nextBookOrderID = 1000;                     

//DECLARATION OF CLASS CONSTANTS
    private static final int FictionTypeCost = 5;
    private static final int NonFictionTypeCost = 10;
    private static final int ReferencePublicationTypeCost = 15;

    private static final int AudioBookTypeCost = 1;
    private static final int IbookTypeCost = 2;
    private static final int HardCoverTypeCost = 4;
    private static final int PaperBackTypeCost = 3;

//DELCARATION OF INSTANCE VARIABLES
    private String AuthorsName;
    private String BookName;
    private int AmountofPages;
    private int id = 0;  
     
    private char BookType;
    private char FictionType;
    private char NonFictionType;
    private char ReferencePublicationType;
    private char StyleType;
     
//CONSTRUCTORS
    
//*****************************************************
// Purpose: Create a new book object
// Interface: IN: None
// Returns: None
// *****************************************************	
    public Book(){
        id = nextBookOrderID++;                                     
        AmountofPages = 0;
        BookType = 'F';
        FictionType = 'm';
        NonFictionType = 'b';
        ReferencePublicationType = 'c';
        StyleType = 's';   
    } //End default construcor
     
//*****************************************************
// Purpose: Create a new book object with initialized properties
// Interface: IN: None
// Returns: None
// *****************************************************
    public Book(String bn, String an,int d,char bt,char ft,char nft, char rpt, char style, boolean r, int oldid){                   
        BookName = bn;
        AuthorsName = an;
         
        //IF STATEMENT (when replacing a book order, ID must stay the same)
        if (r == false) {
            id = nextBookOrderID++; 
        } //End if r is false (no replacement)
        else {
            id = oldid;
        } //End else (for when you replace a book order, ID must stay the same)
         
        AmountofPages =d;                                          
        BookType = bt;
        FictionType = ft;
        NonFictionType = nft;
        ReferencePublicationType = rpt;
        StyleType = style;      
    } //End initialized constructor

//ACCESSORS
    
//*****************************************************
// Purpose: Get the book order's ID
// Interface: IN: none
// Returns: ID
// *****************************************************   
    public int getId(){
        return id;
    } //End getId
     
//*****************************************************
// Purpose: Calculate and return the book type cost
// Interface: IN: none
// Returns: book type cost
// *****************************************************   
    public double getBookTypeCost(){
        double BookTypeCost = 0;
        switch (BookType) {
            case 'F':
                BookTypeCost = FictionTypeCost + AmountofPages * 0.01;
            break;
            case 'N':
                BookTypeCost = NonFictionTypeCost + AmountofPages * 0.01;
                break;
            case 'R':
                BookTypeCost = ReferencePublicationTypeCost + AmountofPages * 0.01;
            break;
            default:
                BookTypeCost = -100;
                break;
        } //End switch BookType
        return BookTypeCost;
    } //End getBookTypeCost
     
//*****************************************************
// Purpose: Calculate and return the book style cost
// Interface: IN: none
// Returns: Book style cost
// *****************************************************   
    public double getBookStyleCost(){
        double BookStyleCost = 0;
        switch (StyleType) {
            case 'A':
                BookStyleCost = AudioBookTypeCost + AmountofPages * 0.01;
            break;
            case 'I':
                BookStyleCost = IbookTypeCost + AmountofPages * 0.01;
            break;
            case 'H':
                BookStyleCost = HardCoverTypeCost + AmountofPages * 0.01;
            break;
            case 'P':
                BookStyleCost = PaperBackTypeCost + AmountofPages * 0.01;
            break;
            default:
                BookStyleCost = -100;
        } //End switch getBookStyleCost
        return BookStyleCost;
    } //End getBookStyleCost   

//*****************************************************
// Purpose: Calculate and return the total book order cost
// Interface: IN: none
// Returns: Total book cost
// *****************************************************
    public double getTotalBookCost(){
        return this.getBookTypeCost() + this.getBookStyleCost(); 
    } //End getTotalBookCost
     
//MUTATORS
    
//*****************************************************
// Purpose: Change the book name for a book
// Interface: IN: new book name
// Returns: none
// *****************************************************
    public void setBookName(String bn){
        BookName = bn;
    } //End setBookName
    
//*****************************************************
// Purpose: Change the author's name for a book
// Interface: IN: new author name
// Returns: none
// *****************************************************
    public void setAuthorsName(String an){
        AuthorsName = an;
    } //End setAuthorsName
    
//*****************************************************
// Purpose: Change the book type for a book
// Interface: IN: new book type
// Returns: none
// *****************************************************
    public void setBookType(char rt){
        BookType = rt;
    } //End setBookType
     
//*****************************************************
// Purpose: Change the fiction type for a book
// Interface: IN: new fiction type
// Returns: none
// *****************************************************
    public void setFictionType(char nt){
        FictionType = nt;
    } //End setFictionType
     
//*****************************************************
// Purpose: Change the nonfiction type for a book
// Interface: IN: new nonfiction type
// Returns: none
// *****************************************************
    public void setNonFictionType(char tvt){
        NonFictionType = tvt;
    } //End setNonFictionType
     
//*****************************************************
// Purpose: Change the reference publication type for a book
// Interface: IN: new reference publication type
// Returns: none
// *****************************************************
    public void setReferencePublicationType(char pt){
        ReferencePublicationType = pt;
    } //End setReferencePublicationType
     
//*****************************************************
// Purpose: Change the style type for a book
// Interface: IN: new style type
// Returns: none
// *****************************************************
    public void setStyleType(char style){
        StyleType = style;
    } //End setStyleType
     
//*****************************************************
// Purpose: Set next ID to last loaded book id + 1
// Interface: IN: new next id number
// Returns: na
// *****************************************************
    public void setNextId(int n){
        nextBookOrderID = n;
    } //End setNextId 
     
//*****************************************************
// Purpose: override the toString method
// Interface: IN: na
// Returns: formatted output
// *****************************************************
    public String toString(){
        String strout = trim(id) + ":" + trim(BookName) + ":" + trim(AuthorsName) + ":" + trim(AmountofPages) +  ":" + trim(BookType) +  ":" + trim(FictionType) +  ":" + trim(NonFictionType) +  ":" + trim(ReferencePublicationType) + ":" + trim(StyleType);
        return strout;
    } //End toString

}  //End class
